'use strict';

module.exports = function(Todos) {

};
