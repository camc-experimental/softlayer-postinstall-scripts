angular
 .module('app')
 .controller('TodoCtrl', ['$scope', '$state', '$http', function($scope,
     $state, $http) {
   $scope.todos = [];
   function getTodos() {        
     $http({
        method: 'GET',
        url: 'api/todos'
     }).then(function (data){
        $scope.todos = data.data;    
     },function (error){
        console.log('Error: ' + error);
     });  
   };
   getTodos();
 
   $scope.addTodo = function() {
      $http({
	method: 'POST',
        url: 'api/todos',
        headers: {'Content-Type': 'application/json'},
        data: {'content': $scope.newTodo.content}
      }).then(function (success){
         $scope.newTodo.content = '';
         $scope.todoForm.content.$setPristine();
         $scope.todoForm.content.$setUntouched();
         $scope.todoForm.$setPristine();
         $scope.todoForm.$setUntouched();
         $('.focus').focus();
         getTodos();
     },function (error){
        console.log('Error: ' + error);
     });
   };
 
   $scope.removeTodo = function(item) {
     $http({
	method: 'DELETE',
        url: 'api/todos/'+item.id
     }).then(function (success){
        getTodos();
     },function (error){
        console.log('Error: ' + error);
     });
   };

 }]);

