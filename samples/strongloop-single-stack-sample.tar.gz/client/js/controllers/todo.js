'use strict';
 
angular
 .module('app')
 .controller('TodoCtrl', ['$scope', '$state', 'Todos', function($scope,
     $state, Todos) {
   $scope.todos = [];
   function getTodos() {
     Todos
       .find()
       .$promise
       .then(function(results) {
         $scope.todos = results;
       });
   }
   getTodos();
 
   $scope.addTodo = function() {
     Todos
       .create($scope.newTodo)
       .$promise
       .then(function(todo) {
         $scope.newTodo.content = '';
         $scope.todoForm.content.$setPristine();
         $scope.todoForm.content.$setUntouched();
         $scope.todoForm.$setPristine();
         $scope.todoForm.$setUntouched();
         $('.focus').focus(); //JQuery hack for refocusing text input
         getTodos();
       });
   };
 
   $scope.removeTodo = function(item) {
     Todos
       .deleteById(item)
       .$promise
       .then(function() {
         getTodos();
       });
   };
 }]);
