var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var methodOverride = require('method-override'); 
var http = require('http');

app.use(bodyParser.json());
app.use(methodOverride());

app.get('/api/todos', function(req, res) {

    var optionsget = {
        host : 'strongloop-server',
        port : 3000,
        path : '/api/Todos',
        method : 'GET'
    };

    var reqGet = http.request(optionsget, function(res1) {
        res1.on('data', function(d) {
            res.send(d);
        });
    });
 
    reqGet.end();
    reqGet.on('error', function(e) {
        res.send(e);
    });
});

app.post('/api/todos', function(req, res) {

    jsonObject = JSON.stringify({
        "content" : req.body.content
    });
   
    var postheaders = {
        'Content-Type' : 'application/json',
        'Accept' : 'application/json'
    };
 
    var optionspost = {
        host : 'strongloop-server',
        port : 3000,
        path : '/api/Todos',
        method : 'POST',
        headers : postheaders
    };
  
    var reqPost = http.request(optionspost, function(res1) {
        res1.on('data', function(d) {
        });
    });
 
    reqPost.write(jsonObject);
    reqPost.end();
    reqPost.on('error', function(e) {
        console.error(e);
    });

    var optionsgetmsg = {
        host : 'strongloop-server',
        port : 3000,
        path : '/api/Todos',
        method : 'GET' 
    };
 
    // do the GET request
    var reqGet = http.request(optionsgetmsg, function(res2) {
        res2.on('data', function(d) {
            res.send(d);
        });
    });
 
    reqGet.end();
    reqGet.on('error', function(e) {
        console.error(e);
    });
   
});


app.delete('/api/todos/:todo_id', function(req, res) {

    var postheaders = {
        'Accept' : 'application/json'
    };
 
    var optionsdelete = {
        host : 'strongloop-server',
        port : 3000,
        path : '/api/Todos/' + req.params.todo_id,
        method : 'DELETE',
        headers : postheaders
    };
  
    var reqDelete = http.request(optionsdelete, function(res1) {
        res1.on('data', function(d) {
        });
    });
 
    reqDelete.end();
    reqDelete.on('error', function(e) {
        console.error(e);
    });
     
    var optionsgetmsg = {
        host : 'strongloop-server', // here only the domain name
        port : 3000,
        path : '/api/Todos', // the rest of the url with parameters if needed
        method : 'GET' // do GET 
    };
 
    var reqGet = http.request(optionsgetmsg, function(res2) {
        res2.on('data', function(d) {
            res.send(d);
        });
 
    });
 
    reqGet.end();
    reqGet.on('error', function(e) {
        console.error(e);
    });

});

var path = require('path');
app.use(express.static(path.resolve(__dirname, '../client')));

app.listen(8080);

app.start = function() {
  return app.listen(function() {
  });
};

console.log("App listening on port 8080");
